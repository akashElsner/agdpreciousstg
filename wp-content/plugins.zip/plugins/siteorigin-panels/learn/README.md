A submodule used to add generic lesson signup modals to SiteOrigin plugins.
