<?php

namespace Google\Site_Kit_Dependencies\TrueBV\Exception;

/**
 * Class DomainOutOfBoundsException
 * @package TrueBV\Exception
 * @author  Sebastian Kroczek <sk@xbug.de>
 */
class DomainOutOfBoundsException extends \Google\Site_Kit_Dependencies\TrueBV\Exception\OutOfBoundsException
{
}
