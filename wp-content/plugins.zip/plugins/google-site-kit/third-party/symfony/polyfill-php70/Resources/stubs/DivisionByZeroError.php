<?php

/* namespace Google\Site_Kit_Dependencies intentionally removed */

class DivisionByZeroError extends \Error
{
}
