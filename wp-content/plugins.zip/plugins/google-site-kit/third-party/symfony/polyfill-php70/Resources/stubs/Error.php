<?php

/* namespace Google\Site_Kit_Dependencies intentionally removed */

class Error extends \Exception
{
}
