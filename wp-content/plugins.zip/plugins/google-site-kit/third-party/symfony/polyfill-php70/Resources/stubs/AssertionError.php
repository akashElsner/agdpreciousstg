<?php

/* namespace Google\Site_Kit_Dependencies intentionally removed */

class AssertionError extends \Error
{
}
