<?php

/* namespace Google\Site_Kit_Dependencies intentionally removed */

class ArithmeticError extends \Error
{
}
