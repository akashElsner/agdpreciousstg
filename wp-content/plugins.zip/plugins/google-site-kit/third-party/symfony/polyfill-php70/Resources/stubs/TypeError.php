<?php

/* namespace Google\Site_Kit_Dependencies intentionally removed */

class TypeError extends \Error
{
}
